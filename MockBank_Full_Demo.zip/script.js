
// MockBank Demo Script (client-side only)
const DEMO = {
  username: "bobeda15",
  password: "Bobeda65$$1",
  securityAnswer: "xena",
  balance: 650789.79,
  routing: "021000021", // sample routing for demos
  account: "123456789012"
};

// utility
function $(id){ return document.getElementById(id); }
function money(n){ return n.toLocaleString('en-US',{style:'currency',currency:'USD'}); }

// init demo state if not present
function initDemo(){ 
  if(!localStorage.getItem('mockbank_state')){
    const state = {
      user: DEMO.username,
      balance: DEMO.balance,
      routing: DEMO.routing,
      account: DEMO.account,
      transactions: [
        {date: recentDate(-2), desc: "Paycheck", amount: 2500.00, balance: DEMO.balance - 0},
        {date: recentDate(-10), desc: "Coffee Shop", amount: -4.50, balance: DEMO.balance - 4.5},
        {date: recentDate(-14), desc: "Grocery Store", amount: -123.45, balance: DEMO.balance - 127.95}
      ]
    };
    localStorage.setItem('mockbank_state', JSON.stringify(state));
  }
}

function recentDate(daysAgo){ 
  const d = new Date(); d.setDate(d.getDate() + daysAgo); return d.toISOString().split('T')[0];
}

// auth helpers
function isLoggedIn(){ return sessionStorage.getItem('mockbank_logged') === '1'; }
function requireAuth(){ if(!isLoggedIn()){ window.location.href = 'index.html'; return false; } return true; }

// pages behavior
document.addEventListener('DOMContentLoaded', ()=>{
  initDemo();
  // index page
  if($('#loginBtn')){
    $('demoBtn').addEventListener('click', ()=>{ $('username').value=DEMO.username; $('password').value=DEMO.password; });
    $('forgotBtn').addEventListener('click', ()=>{ $('recovery').classList.remove('hidden'); });
    $('cancelRecovery').addEventListener('click', ()=>{ $('recovery').classList.add('hidden'); $('recoverMsg').textContent=''; });
    $('loginBtn').addEventListener('click', ()=>{
      const u = $('username').value.trim();
      const p = $('password').value;
      if(u === DEMO.username && p === DEMO.password){
        sessionStorage.setItem('mockbank_logged','1');
        window.location.href = 'dashboard.html';
      } else {
        $('msg').textContent = 'Incorrect username or password (demo).';
      }
    });
    $('recoverBtn').addEventListener('click', ()=>{
      const a = ($('secAnswer').value || '').trim().toLowerCase();
      if(!a){ $('recoverMsg').textContent='Please enter an answer.'; return; }
      if(a === DEMO.securityAnswer.toLowerCase()){
        $('recoverMsg').style.color='green';
        $('recoverMsg').textContent = 'Correct. Demo password: ' + DEMO.password;
      } else {
        $('recoverMsg').style.color='red';
        $('recoverMsg').textContent = 'Incorrect answer.';
      }
    });
  }

  // dashboard page
  if($('#balanceDisplay')){
    if(!requireAuth()) return;
    const state = JSON.parse(localStorage.getItem('mockbank_state'));
    $('#balanceDisplay').textContent = money(state.balance);
    $('#routing').textContent = state.routing;
    $('#acct').textContent = '**** ' + state.account.slice(-4);
    $('#recentList').innerHTML = state.transactions.slice(0,3).map(t => `<div>${t.date} • ${t.desc} <strong style="float:right">${money(t.amount)}</strong></div>`).join('');
    // logout nav
    const outs = document.querySelectorAll('[id^=logoutNav]');
    outs.forEach(b=>b.addEventListener('click', ()=>{ sessionStorage.removeItem('mockbank_logged'); window.location.href='index.html'; }));
  }

  // transactions page
  if($('#txTable')){
    if(!requireAuth()) return;
    const state = JSON.parse(localStorage.getItem('mockbank_state'));
    const tbody = $('#txTable').querySelector('tbody');
    tbody.innerHTML = state.transactions.map(t => `<tr><td>${t.date}</td><td>${t.desc}</td><td>${money(t.amount)}</td><td>${money(t.balance)}</td></tr>`).join('');
    document.querySelectorAll('[id^=logoutNav]').forEach(b=>b.addEventListener('click', ()=>{ sessionStorage.removeItem('mockbank_logged'); window.location.href='index.html'; }));
  }

  // transfer page
  if($('#sendBtn')){
    if(!requireAuth()) return;
    const state = JSON.parse(localStorage.getItem('mockbank_state'));
    $('#sendBtn').addEventListener('click', ()=>{
      const to = ($('#toAcct').value||'').trim();
      const amt = parseFloat(($('#toAmount').value||'').trim());
      const memo = $('#toMemo').value||'';
      const msg = $('#transferMsg');
      msg.style.color='red';
      if(!to || isNaN(amt) || amt<=0){ msg.textContent='Enter valid account and amount.'; return; }
      if(amt > state.balance){ msg.textContent='Insufficient funds (demo).'; return; }
      // simulate processing with a loading dot animation
      msg.style.color= '#0b5cff'; msg.textContent='Processing...';
      setTimeout(()=>{
        // update state
        state.balance = +(state.balance - amt).toFixed(2);
        const tx = {date: new Date().toISOString().split('T')[0], desc: 'Transfer to ' + to, amount: -amt, balance: state.balance, memo: memo};
        state.transactions.unshift(tx);
        localStorage.setItem('mockbank_state', JSON.stringify(state));
        msg.style.color='green'; msg.textContent = 'Transfer complete (demo).';
      }, 1200);
    });
    document.querySelectorAll('[id^=logoutNav]').forEach(b=>b.addEventListener('click', ()=>{ sessionStorage.removeItem('mockbank_logged'); window.location.href='index.html'; }));
  }

  // profile page
  if($('#resetBtn')){
    if(!requireAuth()) return;
    const state = JSON.parse(localStorage.getItem('mockbank_state'));
    $('#profileUser').textContent = state.user;
    $('#profileAcct').textContent = '**** ' + state.account.slice(-4);
    $('#profileRouting').textContent = state.routing;
    $('#resetBtn').addEventListener('click', ()=>{
      localStorage.removeItem('mockbank_state');
      initDemo();
      $('#resetMsg').textContent = 'Demo state reset.';
    });
    document.querySelectorAll('[id^=logoutNav]').forEach(b=>b.addEventListener('click', ()=>{ sessionStorage.removeItem('mockbank_logged'); window.location.href='index.html'; }));
  }
});

function goTo(url){ window.location.href = url; }
